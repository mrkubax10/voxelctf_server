#ifndef SRC_UTILS_HPP
#define SRC_UTILS_HPP
#include <vector>
#include <iostream>
#include <sstream>
std::vector<std::string> split(std::string str,char ch);
#endif