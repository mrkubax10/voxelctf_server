# voxelctf_server
Server software for voxelctf (still unfinished) game. **WARNING!** This software is still unfinished and it shouldn't be used to host voxelctf server.

## voxelctf
VoxelCTF is FPS game with CTF (Capture The Flag) gamemode. It's simillar to other voxel games. This project isn't downloadable yet.
